from .src.PhyObjects import (
    MassPoint, 
    Particles, 
    Wall, 
    Simulation, 
    Gas
)